package ifmt.cba.estoquev1.vo;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
public class ProdutoVO implements Serializable {

    private int codigo;
    private String nome;
    private int estoque;

    public void adicionarEstoque(int quantidade){
        if (quantidade > 0) {
            this.estoque += quantidade;
        }
    }

    public void baixarEstoque(int quantidade) {
        if (quantidade > 0) {
            if (quantidade <= this.estoque) {
                this.estoque -= quantidade;
            }
        }
    }
}
