package ifmt.cba.estoquev1.negocio;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Service;

import ifmt.cba.estoquev1.vo.ProdutoVO;

@Service
public class GerenciadorEstoque {

    private List<ProdutoVO> listaProduto;
    private AtomicInteger contador;

    public GerenciadorEstoque() {
        this.listaProduto = new ArrayList<ProdutoVO>();
        this.contador = new AtomicInteger();
        
        //para facilitar o teste com o Postman
        ProdutoVO produtoVO = new ProdutoVO();
        produtoVO.setNome("ProdutoTeste1");
        produtoVO.setEstoque(100);
        this.novoProduto(produtoVO);
    }

    public void novoProduto(ProdutoVO produtoVO) {
        if (produtoVO != null) {
            produtoVO.setCodigo(contador.incrementAndGet());
            this.listaProduto.add(produtoVO);
        }
    }

    public void removerProduto(int codigo) {
        ProdutoVO produtoVO = this.buscarPorCodigo(codigo);
        if (produtoVO != null) {
            this.listaProduto.remove(produtoVO);
        }
    }

    public void adicionarEstoque(int codigo, int quantidade) {
        ProdutoVO produtoVO = this.buscarPorCodigo(codigo);
        if (produtoVO != null && quantidade > 0) {
            ProdutoVO produtoVOTemp = this.listaProduto.get(this.listaProduto.indexOf(produtoVO));
            produtoVOTemp.adicionarEstoque(quantidade);
        }
    }

    public void baixarEstoque(int codigo, int quantidade) {
        ProdutoVO produtoVO = this.buscarPorCodigo(codigo);
        if (produtoVO != null && quantidade > 0) {
            ProdutoVO produtoVOTemp = this.listaProduto.get(this.listaProduto.indexOf(produtoVO));
            produtoVOTemp.baixarEstoque(quantidade);
        }
    }

    public ProdutoVO buscarPorCodigo(int codigo) {

        ProdutoVO produtoVOTemp = null;

        for (ProdutoVO produtoVO : this.listaProduto) {
            if (produtoVO.getCodigo() == codigo) {
                produtoVOTemp = produtoVO;
                break;
            }
        }

        return produtoVOTemp;
    }

    public int contadorProdutos() {
        return this.listaProduto.size();
    }

    public List<ProdutoVO> listarTodos() {
        return this.listaProduto;
    }

    public ProdutoVO buscarUtimo() {
        return this.listaProduto.get(listaProduto.size() - 1);
    }

    public int totalizarEstoqueFisico() {
        int total = 0;
        for (ProdutoVO produtoVO : this.listaProduto) {
            total += produtoVO.getEstoque();
        }
        return total;
    }
}
