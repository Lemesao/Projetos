from django.urls import path
from .views import listar_funcionarios, adicionar_funcionario, editar_funcionario, excluir_funcionario

urlpatterns = [
    path('', listar_funcionarios, name='listar_funcionarios'),
    path('adicionar/', adicionar_funcionario, name='adicionar_funcionario'),
    path('editar/<int:id_funcionario>/', editar_funcionario, name='editar_funcionario'),
    path('excluir/<int:id_funcionario>/', excluir_funcionario, name='excluir_funcionario'),
]
