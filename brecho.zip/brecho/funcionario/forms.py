from django import forms
from django.db import connection

class FuncionarioForm(forms.Form):
    nome = forms.CharField(max_length=100, label="Nome")
    cpf = forms.CharField(max_length=14, label="CPF")
    celular = forms.CharField(max_length=20, label="Celular")
    email = forms.EmailField(label="Email")
    login = forms.CharField(max_length=50, label="Login")
    senha = forms.CharField(max_length=20, widget=forms.PasswordInput, label="Senha")
    dt_nasc = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label="Data de Nascimento")
    dt_contra = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}), label="Data de Contratação")
    sexo = forms.ChoiceField(choices=[], label="Sexo")  
    ativo = forms.ChoiceField(choices=[], label="Ativo")  

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Preencher os campos dinâmicos com dados do banco
        self.fields['sexo'].choices = self.get_sexo_choices()
        self.fields['ativo'].choices = self.get_ativo_choices()

    def get_sexo_choices(self):
        # Consulta SQL para obter as opções de sexo
        with connection.cursor() as cursor:
            cursor.execute("SELECT DISTINCT SEXO FROM FUNCIONARIO")
            sexo_options = cursor.fetchall()
        return [(option[0], option[0]) for option in sexo_options if option[0]]

    def get_ativo_choices(self):
        # Consulta SQL para obter as opções de status ativo
        with connection.cursor() as cursor:
            cursor.execute("SELECT DISTINCT ATIVO FROM FUNCIONARIO")
            ativo_options = cursor.fetchall()
        return [(option[0], "Ativo" if option[0] == "S" else "Inativo") for option in ativo_options if option[0]]
