from django.shortcuts import render, redirect, get_object_or_404
from django.db import connection

def listar_vendas(request):
    """ Lista todas as vendas com informações detalhadas do banco de dados """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT v.ID_VENDA, CONCAT('Roupa ID ', r.ID_ROUPA, ' - ', r.TAMANHO) AS ROUPA, 
                   f.NOME AS FUNCIONARIO, c.NOME AS CLIENTE, 
                   fp.DESCRICAO AS FORMA_PAGAMENTO, v.ENTREGUE, v.DT_VENDA, 
                   CASE WHEN v.FINALIZADO = 'S' THEN 'Finalizado' ELSE 'Pendente' END AS STATUS
            FROM VENDA v
            LEFT JOIN ROUPA r ON v.ID_ROUPA = r.ID_ROUPA
            LEFT JOIN FUNCIONARIO f ON v.ID_FUNCIONARIO = f.ID_FUNCIONARIO
            LEFT JOIN CLIENTE c ON v.ID_CLIENTE = c.ID_CLIENTE
            LEFT JOIN FORMA_PAGAMENTO fp ON v.ID_FORMA_PAGAMENTO = fp.ID_FORMA_PAGAMENTO
            ORDER BY v.DT_VENDA DESC
        """)
        vendas = cursor.fetchall()

    return render(request, 'vendas/lista.html', {'vendas': vendas})
