from django.urls import path
from .views import listar_vendas

urlpatterns = [
    path('vendas/', listar_vendas, name='listar_vendas'),
]
