import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JogoDaVelha extends JFrame implements ActionListener {
    private JButton[][] botoes = new JButton[3][3];
    private JLabel statusLabel;
    private int jogadorAtual = 1; // 1 para 'X', 2 para 'O'
    private int vitoriasJogador1 = 0, vitoriasJogador2 = 0;
    private JLabel placarLabel;

    public JogoDaVelha() {
        setTitle("Jogo da Velha");
        setSize(400, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        statusLabel = new JLabel("Vez do Jogador X", SwingConstants.CENTER);
        add(statusLabel, BorderLayout.NORTH);

        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(3, 3));
        add(painel, BorderLayout.CENTER);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botoes[i][j] = new JButton("");
                botoes[i][j].setFont(new Font("Arial", Font.PLAIN, 40));
                botoes[i][j].setFocusPainted(false);
                botoes[i][j].addActionListener(this);
                painel.add(botoes[i][j]);
            }
        }

        placarLabel = new JLabel("Placar - X: 0 | O: 0", SwingConstants.CENTER);
        add(placarLabel, BorderLayout.SOUTH);

        JButton reiniciarButton = new JButton("Reiniciar Jogo");
        reiniciarButton.addActionListener(e -> reiniciarJogo());
        add(reiniciarButton, BorderLayout.SOUTH);
    }

    public void actionPerformed(ActionEvent e) {
        JButton botaoClicado = (JButton) e.getSource();
        if (!botaoClicado.getText().equals("")) return; // Impedir jogada em célula ocupada
        
        botaoClicado.setText(jogadorAtual == 1 ? "X" : "O");
        if (verificarVitoria()) {
            if (jogadorAtual == 1) {
                vitoriasJogador1++;
            } else {
                vitoriasJogador2++;
            }
            salvarResultado(jogadorAtual == 1 ? "X" : "O");
            JOptionPane.showMessageDialog(this, "Jogador " + (jogadorAtual == 1 ? "X" : "O") + " venceu!");
            atualizarPlacar();
            limparTabuleiro();
        } else if (verificarEmpate()) {
            salvarResultado("Empate");
            JOptionPane.showMessageDialog(this, "Empate!");
            limparTabuleiro();
        } else {
            jogadorAtual = 3 - jogadorAtual; // Alterna entre 1 e 2
            statusLabel.setText("Vez do Jogador " + (jogadorAtual == 1 ? "X" : "O"));
        }
    }

    private boolean verificarVitoria() {
        for (int i = 0; i < 3; i++) {
            if (botoes[i][0].getText().equals(botoes[i][1].getText()) &&
                botoes[i][1].getText().equals(botoes[i][2].getText()) &&
                !botoes[i][0].getText().equals("")) {
                return true;
            }
            if (botoes[0][i].getText().equals(botoes[1][i].getText()) &&
                botoes[1][i].getText().equals(botoes[2][i].getText()) &&
                !botoes[0][i].getText().equals("")) {
                return true;
            }
        }
        if (botoes[0][0].getText().equals(botoes[1][1].getText()) &&
            botoes[1][1].getText().equals(botoes[2][2].getText()) &&
            !botoes[0][0].getText().equals("")) {
            return true;
        }
        if (botoes[0][2].getText().equals(botoes[1][1].getText()) &&
            botoes[1][1].getText().equals(botoes[2][0].getText()) &&
            !botoes[0][2].getText().equals("")) {
            return true;
        }
        return false;
    }

    private boolean verificarEmpate() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (botoes[i][j].getText().equals("")) {
                    return false;
                }
            }
        }
        return true;
    }

    private void salvarResultado(String vencedor) {
        JSONObject resultado = new JSONObject();
        resultado.put("data", LocalDateTime.now().toString());
        resultado.put("vencedor", vencedor);
    
        try (FileWriter file = new FileWriter("historico.json", true)) {
            file.write(resultado.toString() + "\n"); // Usa toString() no lugar de toJSONString()
            file.flush(); // Garante que os dados são gravados corretamente
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    private void limparTabuleiro() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botoes[i][j].setText("");
            }
        }
    }

    private void atualizarPlacar() {
        placarLabel.setText("Placar - X: " + vitoriasJogador1 + " | O: " + vitoriasJogador2);
    }

    private void reiniciarJogo() {
        vitoriasJogador1 = 0;
        vitoriasJogador2 = 0;
        atualizarPlacar();
        limparTabuleiro();
        jogadorAtual = 1;
        statusLabel.setText("Vez do Jogador X");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JogoDaVelha jogo = new JogoDaVelha();
            jogo.setVisible(true);
        });
    }
}
