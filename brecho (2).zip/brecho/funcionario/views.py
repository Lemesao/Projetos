from django.shortcuts import render, redirect, get_object_or_404
from django.db import connection
from .forms import FuncionarioForm

def listar_funcionarios(request):
    """ Lista todos os funcionários cadastrados no banco de dados, ordenando por nome """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT ID_FUNCIONARIO, NOME, CPF, CELULAR, EMAIL, LOGIN, DT_NASC, DT_CONTRA, SEXO, 
                   CASE WHEN ATIVO = 'S' THEN 'Ativo' ELSE 'Inativo' END AS Status
            FROM FUNCIONARIO
            ORDER BY NOME ASC
        """)
        funcionarios = cursor.fetchall()

    return render(request, 'funcionario/lista.html', {'funcionarios': funcionarios})

def adicionar_funcionario(request):
    """ Adiciona um novo funcionário ao banco de dados """
    if request.method == 'POST':
        form = FuncionarioForm(request.POST)
        if form.is_valid():
            with connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO FUNCIONARIO (NOME, CPF, CELULAR, EMAIL, LOGIN, SENHA, DT_NASC, DT_CONTRA, SEXO, ATIVO)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, [
                    form.cleaned_data['nome'],
                    form.cleaned_data['cpf'],
                    form.cleaned_data['celular'],
                    form.cleaned_data['email'],
                    form.cleaned_data['login'],
                    form.cleaned_data['senha'],  # ⚠️ Em produção, criptografe a senha!
                    form.cleaned_data['dt_nasc'],
                    form.cleaned_data['dt_contra'],
                    form.cleaned_data['sexo'],
                    form.cleaned_data['ativo']
                ])
            return redirect('listar_funcionarios')
    else:
        form = FuncionarioForm()

    return render(request, 'funcionario/adicionar.html', {'form': form})

def editar_funcionario(request, id_funcionario):
    """ Edita os dados de um funcionário existente """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT NOME, CPF, CELULAR, EMAIL, LOGIN, SENHA, 
                   TO_CHAR(DT_NASC, 'YYYY-MM-DD'), TO_CHAR(DT_CONTRA, 'YYYY-MM-DD'), 
                   SEXO, ATIVO
            FROM FUNCIONARIO WHERE ID_FUNCIONARIO = %s
        """, [id_funcionario])
        funcionario = cursor.fetchone()

    if not funcionario:
        return redirect('listar_funcionarios')

    if request.method == 'POST':
        form = FuncionarioForm(request.POST)
        if form.is_valid():
            with connection.cursor() as cursor:
                cursor.execute("""
                    UPDATE FUNCIONARIO 
                    SET NOME=%s, CPF=%s, CELULAR=%s, EMAIL=%s, LOGIN=%s, SENHA=%s, DT_NASC=%s, DT_CONTRA=%s, SEXO=%s, ATIVO=%s 
                    WHERE ID_FUNCIONARIO=%s
                """, [
                    form.cleaned_data['nome'],
                    form.cleaned_data['cpf'],
                    form.cleaned_data['celular'],
                    form.cleaned_data['email'],
                    form.cleaned_data['login'],
                    form.cleaned_data['senha'],  # ⚠️ Em produção, criptografe a senha!
                    form.cleaned_data['dt_nasc'],
                    form.cleaned_data['dt_contra'],
                    form.cleaned_data['sexo'],
                    form.cleaned_data['ativo'],
                    id_funcionario
                ])
            return redirect('listar_funcionarios')
    else:
        form = FuncionarioForm(initial={
            'nome': funcionario[0],
            'cpf': funcionario[1],
            'celular': funcionario[2],
            'email': funcionario[3],
            'login': funcionario[4],
            'senha': funcionario[5],
            'dt_nasc': funcionario[6],
            'dt_contra': funcionario[7],
            'sexo': funcionario[8],
            'ativo': funcionario[9],
        })

    return render(request, 'funcionario/editar.html', {'form': form})

def excluir_funcionario(request, id_funcionario):
    """ Exclui um funcionário do banco de dados """
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM FUNCIONARIO WHERE ID_FUNCIONARIO=%s", [id_funcionario])
    return redirect('listar_funcionarios')
