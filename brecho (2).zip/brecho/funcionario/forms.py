from django import forms
from django.db import connection

class FuncionarioForm(forms.Form):
    nome = forms.CharField(max_length=100, label="Nome")
    cpf = forms.CharField(max_length=14, label="CPF")
    celular = forms.CharField(max_length=20, label="Celular")
    email = forms.EmailField(label="E-mail")
    login = forms.CharField(max_length=50, label="Login")
    senha = forms.CharField(widget=forms.PasswordInput, max_length=20, label="Senha")

    dt_nasc = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        label="Data de Nascimento"
    )
    dt_contra = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        label="Data de Contratação"
    )

    sexo = forms.ChoiceField(choices=[('M', 'Masculino'), ('F', 'Feminino')], label="Sexo")
    ativo = forms.ChoiceField(
        choices=[('S', 'Ativo'), ('N', 'Inativo')],
        label="Status",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
