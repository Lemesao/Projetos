from django import forms
from django.db import connection

class VendaForm(forms.Form):
    id_roupa = forms.ChoiceField(label="Roupa", choices=[])
    id_funcionario = forms.ChoiceField(label="Funcionário", choices=[])
    id_cliente = forms.ChoiceField(label="Cliente", choices=[])
    id_forma_pagamento = forms.ChoiceField(label="Forma de Pagamento", choices=[])

    entregue = forms.CharField(max_length=50, label="Entregue")
    dt_venda = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        label="Data da Venda"
    )
    finalizado = forms.ChoiceField(choices=[('S', 'Finalizado'), ('N', 'Pendente')], label="Status")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Buscar opções do banco para os campos relacionados
        self.fields['id_roupa'].choices = self.get_choices("SELECT ID_ROUPA, TAMANHO FROM ROUPA")
        self.fields['id_funcionario'].choices = self.get_choices("SELECT ID_FUNCIONARIO, NOME FROM FUNCIONARIO")
        self.fields['id_cliente'].choices = self.get_choices("SELECT ID_CLIENTE, NOME FROM CLIENTE")
        self.fields['id_forma_pagamento'].choices = self.get_choices("SELECT ID_FORMA_PAGAMENTO, DESCRICAO FROM FORMA_PAGAMENTO")

    def get_choices(self, query):
        """Executa a query e retorna opções para o ChoiceField."""
        with connection.cursor() as cursor:
            cursor.execute(query)
            results = cursor.fetchall()
        return [(str(result[0]), result[1]) for result in results]
