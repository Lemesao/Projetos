from django.urls import path
from .views import listar_vendas, adicionar_venda, editar_venda, excluir_venda

urlpatterns = [
    path('vendas/', listar_vendas, name='listar_vendas'),
    path('vendas/adicionar/', adicionar_venda, name='adicionar_venda'),
    path('vendas/editar/<int:id_venda>/', editar_venda, name='editar_venda'),
    path('vendas/excluir/<int:id_venda>/', excluir_venda, name='excluir_venda'),
]
