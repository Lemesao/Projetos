from django.shortcuts import render, redirect, get_object_or_404
from django.db import connection
from .forms import VendaForm

def listar_vendas(request):
    """ Lista todas as vendas registradas no banco de dados, ordenando por nome do funcionário e do cliente """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT v.ID_VENDA, CONCAT('Roupa ID ', r.ID_ROUPA, ' - ', r.TAMANHO) AS ROUPA, 
                   f.NOME AS FUNCIONARIO, c.NOME AS CLIENTE, 
                   fp.DESCRICAO AS FORMA_PAGAMENTO, v.ENTREGUE, v.DT_VENDA, 
                   CASE WHEN v.FINALIZADO = 'S' THEN 'Finalizado' ELSE 'Pendente' END AS STATUS
            FROM VENDA v
            LEFT JOIN ROUPA r ON v.ID_ROUPA = r.ID_ROUPA
            LEFT JOIN FUNCIONARIO f ON v.ID_FUNCIONARIO = f.ID_FUNCIONARIO
            LEFT JOIN CLIENTE c ON v.ID_CLIENTE = c.ID_CLIENTE
            LEFT JOIN FORMA_PAGAMENTO fp ON v.ID_FORMA_PAGAMENTO = fp.ID_FORMA_PAGAMENTO
            ORDER BY f.NOME ASC, c.NOME ASC
        """)
        vendas = cursor.fetchall()

    return render(request, 'vendas/lista.html', {'vendas': vendas})


    return render(request, 'vendas/lista.html', {'vendas': vendas})

def adicionar_venda(request):
    """ Cadastra uma nova venda """
    if request.method == 'POST':
        form = VendaForm(request.POST)
        if form.is_valid():
            with connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO VENDA (ID_ROUPA, ID_FUNCIONARIO, ID_CLIENTE, ID_FORMA_PAGAMENTO, ENTREGUE, DT_VENDA, FINALIZADO)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, [
                    form.cleaned_data['id_roupa'],
                    form.cleaned_data['id_funcionario'],
                    form.cleaned_data['id_cliente'],
                    form.cleaned_data['id_forma_pagamento'],
                    form.cleaned_data['entregue'],
                    form.cleaned_data['dt_venda'],
                    form.cleaned_data['finalizado']
                ])
            return redirect('listar_vendas')
    else:
        form = VendaForm()

    return render(request, 'vendas/adicionar.html', {'form': form})

def editar_venda(request, id_venda):
    """ Edita uma venda existente e exibe a data correta """
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT ID_ROUPA, ID_FUNCIONARIO, ID_CLIENTE, ID_FORMA_PAGAMENTO, ENTREGUE, 
                   TO_CHAR(DT_VENDA, 'YYYY-MM-DD'), FINALIZADO
            FROM VENDA WHERE ID_VENDA = %s
        """, [id_venda])
        venda = cursor.fetchone()

    if not venda:
        return redirect('listar_vendas')

    if request.method == 'POST':
        form = VendaForm(request.POST)
        if form.is_valid():
            with connection.cursor() as cursor:
                cursor.execute("""
                    UPDATE VENDA 
                    SET ID_ROUPA=%s, ID_FUNCIONARIO=%s, ID_CLIENTE=%s, ID_FORMA_PAGAMENTO=%s, ENTREGUE=%s, DT_VENDA=%s, FINALIZADO=%s
                    WHERE ID_VENDA=%s
                """, [
                    form.cleaned_data['id_roupa'],
                    form.cleaned_data['id_funcionario'],
                    form.cleaned_data['id_cliente'],
                    form.cleaned_data['id_forma_pagamento'],
                    form.cleaned_data['entregue'],
                    form.cleaned_data['dt_venda'],
                    form.cleaned_data['finalizado'],
                    id_venda
                ])
            return redirect('listar_vendas')
    else:
        form = VendaForm(initial={
            'id_roupa': venda[0],
            'id_funcionario': venda[1],
            'id_cliente': venda[2],
            'id_forma_pagamento': venda[3],
            'entregue': venda[4],
            'dt_venda': venda[5],  # A data agora está formatada corretamente
            'finalizado': venda[6],
        })

    return render(request, 'vendas/editar.html', {'form': form})

def excluir_venda(request, id_venda):
    """ Exclui uma venda do banco de dados """
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM VENDA WHERE ID_VENDA=%s", [id_venda])
    return redirect('listar_vendas')
