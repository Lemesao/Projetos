import 'package:flutter/material.dart';
import 'package:nakombi/clientes/pages/perfil_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Nakombi Baixa Gastronomia"),
        centerTitle: true,
      ),

      body:
          [
            Container(color: const Color.fromARGB(255, 186, 189, 16)),
            Container(color: const Color.fromARGB(255, 54, 136, 37)),
            Container(color: const Color.fromARGB(255, 23, 130, 218)),
            PerfilPage(),
          ][_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) {
          setState(() {
            _index = value;
          });
        },
        destinations: [
          NavigationDestination(icon: Icon(Icons.home), label: "Home"),
          NavigationDestination(
            icon: Icon(Icons.shopping_cart),
            label: "Vendas",
          ),
          NavigationDestination(icon: Icon(Icons.list), label: "Relatórios"),
          NavigationDestination(
            icon: Icon(Icons.person_2),
            label: "Perfil de Usuario",
          ),
        ],
      ),
    );
  }
}
