import 'package:flutter/material.dart';

class MyTextFormField extends StatelessWidget {
  const MyTextFormField(this.label, {super.key});
  final String? label;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderSide: BorderSide(width: 1.0)),
        enabledBorder: OutlineInputBorder(borderSide: BorderSide(width: 1.0)),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            width: 1.2,
            color: const Color.fromARGB(185, 11, 121, 34),
          ),
        ),
      ),
    );
  }
}
