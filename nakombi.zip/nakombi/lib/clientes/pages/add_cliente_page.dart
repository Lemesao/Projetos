import 'package:flutter/material.dart';
import 'package:nakombi/commons/my_textformfield.dart';

class AddClientePage extends StatelessWidget {
  const AddClientePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Registrar Cliente')),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0, vertical: 30),
        child: Column(
          children: [
            MyTextFormField('Nome'),
            MyTextFormField('Endereço'),
            MyTextFormField('Telefone'),
            MyTextFormField('CEP'),
          ],
        ),
      ),
    );
  }
}
